# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/).

## [Unreleased]

- Chart baseline: CronJob-based IPMI fan control with onepassworditem subchart for credentials.
